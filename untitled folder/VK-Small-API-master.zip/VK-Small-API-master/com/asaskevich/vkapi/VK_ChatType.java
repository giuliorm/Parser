package com.asaskevich.vkapi;

/**
 * Chat types
 * @author Alex Saskevich
 */
public enum VK_ChatType {
	CHAT, DIALOG
}
