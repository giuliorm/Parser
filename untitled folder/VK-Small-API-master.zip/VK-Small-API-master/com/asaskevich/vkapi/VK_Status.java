package com.asaskevich.vkapi;

/**
 * Pretty simple
 * @author Alex Saskevich
 */
public enum VK_Status {
	OFFLINE, ONLINE, ONLINE_MOBILE
}
