VK-Small-API
============

Small Java API used for work with VK

Example of using is in VK_Example.java

Completed:
* Authorization
* Counters of new messages, friends, answers and groups
* Total count of friends
* Count of friends that online
* Loading basic data about friends - id, name, photo
* Status of some friend - on-line or off-line
* Send private message to chat or user
* Load list of dialogs
* Load list of groups
